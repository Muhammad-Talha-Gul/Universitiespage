<footer class="footer text-right">
    {{date("Y")}} © Webnet Pakistan.
</footer>