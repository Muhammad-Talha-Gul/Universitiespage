<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Reply Email</title>
</head>
<body>
    <h2>User Reply Email</h2>
    <p>{{ $reply }}</p>
</body>
</html>
