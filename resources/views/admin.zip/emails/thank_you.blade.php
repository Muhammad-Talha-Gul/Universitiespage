<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Universities Page</title>
</head>
<body>
    <p>Thank you for contacting Universities Page.</p>

    <p>A dedicated counselor will be in touch with you shortly to provide a comprehensive assessment of your study abroad options.</p>

    <p>Best regards,<br>
    Universities Page</p>
</body>
</html>
