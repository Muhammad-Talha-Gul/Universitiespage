<html>
<thead></thead>
<body>
<p><b>Name:</b>{{$name}}</p>
<p><b>Email:</b>{{$email}}</p>
<p><b>Subject:</b>{{($subject)??''}}</p>
<br>
<p><b>Message:</b><br>{{$contact_message}}</p>
<br><br>
------------------------------------------------
<p>This email is sent from www.Universitiespage.com</p>
</body>
</html>