<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <p>{{ $message }}</p>
</body>
</html>
