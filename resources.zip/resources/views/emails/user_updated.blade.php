<html>
<thead></thead>
<body>
<h4>Your account details has been updated</h4>
<p>below are the details of your account</p>
<br>
<p><b>Name:</b>{{$name}}</p>
<p><b>Email:</b>{{$email}}</p>
<p><b>Password:</b>{{$password}}</p>
<br><br>
<br><br>
------------------------------------------------
<p>This email is sent from www.universitiespage.com</p>
</body>
</html>